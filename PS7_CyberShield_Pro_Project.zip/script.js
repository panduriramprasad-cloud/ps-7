const STORAGE = "ps7CyberShieldPro";

const defaultState = {
  theme: "dark",
  scans: [],
  gameScore: 0,
  gameIndex: 0,
  gameCompleted: false,
  quizScore: 0,
  quizIndex: 0,
  quizCompleted: false,
  riskScore: null,
  riskCompleted: false
};

const state = Object.assign(defaultState, JSON.parse(localStorage.getItem(STORAGE) || "{}"));

const phishingCases = [
  {subject:"Urgent: Verify your bank account",from:"security@paypa1-support.example",body:"Your account will be closed within 30 minutes. Verify your login immediately using the secure link below.",url:"http://paypa1-support.example/verify",answer:"phishing",why:"Look-alike domain, urgent deadline, and a login request are strong phishing indicators."},
  {subject:"College timetable update",from:"notice@campus.example.edu",body:"The semester timetable has been updated. Open the student portal using the address you normally type into your browser.",url:"No direct login link",answer:"safe",why:"The message avoids asking for a password and recommends an independent way to access the portal."},
  {subject:"You won ₹50,000!",from:"winner@reward-example.net",body:"Claim your prize in 10 minutes. Enter your card number and OTP on the following page.",url:"http://instant-reward.example/claim",answer:"phishing",why:"Unexpected prize + urgency + card/OTP request is a classic scam pattern."},
  {subject:"Your sign-in code",from:"no-reply@service.example",body:"A sign-in code was requested for your account. If this was not you, contact support from the official website.",url:"No link included",answer:"safe",why:"It does not ask the user to disclose the code and recommends using a separately verified support path."},
  {subject:"Job shortlisted — processing fee",from:"jobs@career-check.example",body:"You have been selected. Pay a processing fee today and send a screenshot of your banking page.",url:"http://career-check.example/pay",answer:"phishing",why:"Unexpected fees and requests for banking information are major warning signs."},
  {subject:"IT password reminder",from:"it-helpdesk@college.example.edu",body:"Your password is nearing expiry. Go to the college website manually and use the normal account settings page.",url:"No direct login link",answer:"safe",why:"The message recommends a manual, independently verified login path and does not request the password."}
];

const quizData = [
  {q:"What is the safest response to an unexpected login link?",o:["Click it quickly","Type the official site yourself","Reply with your password","Forward it to friends"],a:1,w:"Using an independently verified website avoids trusting a potentially malicious link."},
  {q:"What does MFA add to account security?",o:["Faster internet","Another verification factor","Free storage","Automatic backups"],a:1,w:"MFA adds an additional verification factor beyond the password."},
  {q:"Which password habit is safest?",o:["One password everywhere","Short passwords","Unique passwords for important accounts","Share passwords with friends"],a:2,w:"Unique passwords limit the damage if one account is compromised."},
  {q:"Should you share an OTP with someone who calls claiming to be support?",o:["Yes, if they sound professional","Only at night","No","Only if they know your name"],a:2,w:"OTP codes are sensitive authentication information and should remain private."},
  {q:"Which is a common phishing sign?",o:["Unexpected urgency","A document you created","A normal offline note","A known saved contact"],a:0,w:"Pressure and urgency are frequently used to push users into unsafe actions."},
  {q:"Why are software security updates important?",o:["They only change icons","They can patch vulnerabilities","They remove all malware automatically","They make passwords unnecessary"],a:1,w:"Updates often contain security fixes for known vulnerabilities."},
  {q:"What should you do with an unexpected attachment?",o:["Open it immediately","Verify the sender and context","Disable antivirus first","Forward it widely"],a:1,w:"Unexpected attachments should be verified before opening."},
  {q:"Who is responsible for everyday cybersecurity?",o:["Only IT staff","Only the government","Everyone using the system","Only the website owner"],a:2,w:"Good security is a shared responsibility among users, admins, developers, and organizations."}
];

const riskQuestions = [
  "I use unique passwords for important accounts.",
  "I use multi-factor authentication where available.",
  "I inspect suspicious links and sender addresses.",
  "I install software and OS security updates regularly.",
  "I never share passwords, OTPs, or recovery codes.",
  "I keep important files backed up.",
  "I review privacy and security settings.",
  "I lock my device when leaving it unattended."
];

const el = id => document.getElementById(id);
const save = () => localStorage.setItem(STORAGE, JSON.stringify(state));
const clamp = (n,min,max) => Math.min(max, Math.max(min,n));

function toast(message) {
  const t = el("toast");
  t.textContent = message;
  t.classList.add("show");
  clearTimeout(window.__toast);
  window.__toast = setTimeout(() => t.classList.remove("show"), 2400);
}

function safeText(value) {
  return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[ch]));
}

function applyTheme() {
  document.documentElement.dataset.theme = state.theme === "light" ? "light" : "dark";
  el("themeBtn").textContent = state.theme === "light" ? "☾" : "☼";
}

el("themeBtn").onclick = () => {
  state.theme = state.theme === "light" ? "dark" : "light";
  save(); applyTheme();
};

el("menuBtn").onclick = () => el("nav").classList.toggle("open");
document.querySelectorAll(".nav a").forEach(a => a.onclick = () => el("nav").classList.remove("open"));

/* -------------------- LIVE SCANNER -------------------- */
let scanMode = "url";

document.querySelectorAll(".scan-tab").forEach(btn => {
  btn.onclick = () => {
    document.querySelectorAll(".scan-tab").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    scanMode = btn.dataset.mode;
    el("scanInput").placeholder = scanMode === "url"
      ? "Paste a URL or website address here..."
      : "Paste a suspicious email, SMS, chat message, or website text here...";
  };
});

document.querySelectorAll(".sample-btn").forEach(btn => {
  btn.onclick = () => {
    const type = btn.dataset.sample;
    if (type === "safe") {
      scanMode = "url";
      setScanTab("url");
      el("scanInput").value = "https://www.example.com/account/security";
    } else {
      scanMode = "message";
      setScanTab("message");
      el("scanInput").value = "URGENT! Your bank account will be suspended in 10 minutes. Verify your password and OTP here: http://bank-secure-login.example/verify";
    }
  };
});

function setScanTab(mode) {
  scanMode = mode;
  document.querySelectorAll(".scan-tab").forEach(b => b.classList.toggle("active", b.dataset.mode === mode));
}

function analyzeInput(input, mode) {
  const text = input.trim();
  const lower = text.toLowerCase();
  let score = 0;
  const findings = [];
  let type = mode;

  const add = (points, title, detail) => {
    score += points;
    findings.push({title, detail});
  };

  if (!text) {
    return {level:"none",score:0,findings:[{title:"No input",detail:"Enter a URL, email, SMS, or message to begin."}],type};
  }

  const hasUrl = /(https?:\/\/|www\.|[a-z0-9-]+\.(com|net|org|co|in|edu|info|biz)(\/|$))/i.test(text);
  if (hasUrl && mode === "message") type = "message";

  const urls = text.match(/https?:\/\/[^\s<>"']+/gi) || [];
  const suspiciousTlds = /\.(zip|mov|top|click|xyz|support|work|live|buzz|gq|tk)(\/|$)/i;
  const lookalike = /(paypa[l1]|micros0ft|g00gle|facebo0k|instaqram|amaz0n|app1e|bank[-_.]?secure|verify[-_.]?account)/i;
  const ipUrl = /https?:\/\/(?:\d{1,3}\.){3}\d{1,3}/i;
  const shortener = /(bit\.ly|tinyurl\.com|t\.co|is\.gd|cutt\.ly|shorturl\.at)/i;
  const unicodeDomain = /xn--/i;
  const credentialWords = /(password|passcode|otp|one[- ]time|cvv|card number|pin|login code|recovery code)/i;
  const urgency = /(urgent|immediately|within \d+|act now|last chance|account.*(close|lock|suspend|delete)|expires? (today|soon))/i;
  const reward = /(won|winner|prize|reward|lottery|free money|cashback)/i;
  const payment = /(pay|payment|processing fee|gift card|crypto|bitcoin|upi)/i;
  const attachment = /(attachment|invoice|document|file attached|download)/i;
  const authority = /(bank|police|tax|government|support|admin|security team|hr)/i;
  const genericGreeting = /(dear customer|dear user|valued customer)/i;

  if (urls.length) {
    if (ipUrl.test(text)) add(28, "Raw IP address", "The link points directly to an IP address instead of a normal domain.");
    if (shortener.test(text)) add(17, "URL shortener", "Shortened links hide the final destination and deserve extra verification.");
    if (lookalike.test(text)) add(30, "Look-alike wording", "The text contains a brand-like or misspelled term commonly used in impersonation.");
    if (suspiciousTlds.test(text)) add(15, "Unusual domain ending", "Some low-cost or uncommon TLDs are frequently seen in suspicious campaigns.");
    if (unicodeDomain.test(text)) add(20, "Punycode domain", "xn-- domains can be legitimate, but they can also be used for look-alike domains.");
    if (urls.some(u => (u.match(/-/g)||[]).length >= 4)) add(9, "Domain complexity", "An unusually complex domain can be a sign of impersonation or deceptive URL construction.");
    try {
      const u = new URL(urls[0]);
      if (u.protocol !== "https:") add(16, "No HTTPS", "The URL uses HTTP. Encryption alone does not prove safety, but HTTPS is expected for modern account pages.");
      if (u.hostname.split(".").length > 3) add(7, "Deep subdomain", "Multiple subdomains can sometimes be used to make a malicious domain look official.");
    } catch {}
  }

  if (urgency.test(text)) add(18, "Urgency / pressure", "The message tries to make you act quickly before you can verify it.");
  if (credentialWords.test(text)) add(18, "Credential request", "Requests for passwords, OTPs, CVV, PINs, or recovery codes are highly sensitive.");
  if (reward.test(text)) add(14, "Unexpected reward", "Prizes or unexpected money offers are common social-engineering bait.");
  if (payment.test(text)) add(14, "Payment request", "Unexpected fees, transfers, gift cards, or crypto requests deserve independent verification.");
  if (attachment.test(text)) add(8, "Attachment/download cue", "Unexpected files can contain malware or redirect you to fake login pages.");
  if (authority.test(text) && (urgency.test(text) || credentialWords.test(text))) add(13, "Authority impersonation", "The message combines an authority claim with pressure or sensitive requests.");
  if (genericGreeting.test(text)) add(5, "Generic greeting", "Generic greetings can indicate bulk targeting, though they are not proof of phishing.");

  const suspiciousPhrases = [
    ["verify your account", 10],
    ["confirm your identity", 9],
    ["security alert", 6],
    ["click here", 8],
    ["login now", 12],
    ["send screenshot", 12],
    ["share otp", 20],
    ["account suspended", 15]
  ];
  suspiciousPhrases.forEach(([phrase,points]) => {
    if (lower.includes(phrase) && !findings.some(f => f.title === phrase)) add(points, `Phrase: "${phrase}"`, "This wording is frequently used in social-engineering messages and should be verified.");
  });

  score = clamp(score, 0, 100);
  let level = "low";
  if (score >= 60) level = "high";
  else if (score >= 30) level = "medium";

  if (!findings.length) {
    findings.push({title:"No major rule triggered", detail:"No strong phishing indicator was detected by this browser-based checker. Still verify the source before taking action."});
  }
  return {level,score,findings,type};
}

function renderScanResult(result, raw) {
  if (result.level === "none") {
    el("scanResult").innerHTML = `<div class="result-empty"><div class="result-icon">!</div><h3>Enter something to scan</h3><p>${safeText(result.findings[0].detail)}</p></div>`;
    return;
  }
  const labels = {low:"LOW RISK",medium:"MEDIUM RISK",high:"HIGH RISK"};
  const color = result.level === "low" ? "var(--green)" : result.level === "medium" ? "var(--yellow)" : "var(--red)";
  const guidance = result.level === "high"
    ? "Do not click, pay, download, or enter credentials. Verify using an official channel you already trust."
    : result.level === "medium"
    ? "Pause and verify the sender, domain, and requested action before continuing."
    : "No major red flag was triggered. Continue to verify unexpected requests before acting.";

  el("scanResult").innerHTML = `
    <div class="result-box">
      <div class="result-top">
        <div><span class="mini-label">ANALYSIS COMPLETE</span><h3>${labels[result.level]}</h3></div>
        <span class="risk-chip ${result.level}">${result.score}/100</span>
      </div>
      <div class="result-score">Rule-based suspicion score</div>
      <div class="score-line"><i style="width:${result.score}%;background:${color}"></i></div>
      <div class="findings">
        ${result.findings.slice(0,7).map(f => `<div class="finding"><b>${safeText(f.title)}</b><br>${safeText(f.detail)}</div>`).join("")}
      </div>
      <div class="safe-message">🛡️ <b>What to do:</b> ${guidance}</div>
    </div>
  `;
}

function addScanHistory(input, result) {
  state.scans.unshift({input: input.slice(0,180), score:result.score, level:result.level, time:new Date().toLocaleString()});
  state.scans = state.scans.slice(0, 20);
  save();
  renderHistory();
  updateDashboard();
}

el("scanBtn").onclick = () => {
  const input = el("scanInput").value.trim();
  const result = analyzeInput(input, scanMode);
  renderScanResult(result, input);
  if (result.level !== "none") {
    addScanHistory(input, result);
    toast(`${result.level.toUpperCase()} risk result created`);
  }
};

el("clearScanBtn").onclick = () => {
  el("scanInput").value = "";
  el("scanResult").innerHTML = `<div class="result-empty"><div class="result-icon">◌</div><h3>Waiting for a scan</h3><p>Your result, score, red flags, and safety guidance will appear here.</p></div>`;
};

function renderHistory() {
  const box = el("scanHistory");
  if (!state.scans.length) {
    box.innerHTML = `<div class="history-empty">No scans yet.</div>`;
    return;
  }
  box.innerHTML = state.scans.map(s => `<div class="history-item"><span class="history-type">${s.time.split(",")[0]}</span><span class="history-content">${safeText(s.input)}</span><span class="history-risk risk-chip ${s.level}">${s.score}</span></div>`).join("");
}
el("clearHistoryBtn").onclick = () => { state.scans=[]; save(); renderHistory(); updateDashboard(); toast("Scan history cleared"); };

/* -------------------- GAME -------------------- */
let localGameAnswered = false;
function renderGame() {
  const item = phishingCases[state.gameIndex] || phishingCases[0];
  el("gameCounter").textContent = `${Math.min(state.gameIndex+1, phishingCases.length)} / ${phishingCases.length}`;
  el("gameCaseTitle").textContent = item.subject;
  el("phishMessage").innerHTML = `
    <div class="message-grid">
      <span>From</span><b>${safeText(item.from)}</b>
      <span>Subject</span><b>${safeText(item.subject)}</b>
    </div>
    <div class="message-body">${safeText(item.body)}</div>
    <div class="message-url">${safeText(item.url)}</div>
  `;
  el("gameFeedback").className = "feedback hidden";
  el("nextGameBtn").classList.add("hidden");
  el("phishBtn").disabled = false; el("safeBtn").disabled = false;
  localGameAnswered = false;
  updateDashboard();
}

function answerGame(choice) {
  if (localGameAnswered) return;
  localGameAnswered = true;
  const item = phishingCases[state.gameIndex];
  const correct = choice === item.answer;
  if (correct) state.gameScore += 10;
  if (state.gameIndex === phishingCases.length - 1) state.gameCompleted = true;
  el("phishBtn").disabled = true; el("safeBtn").disabled = true;
  const fb = el("gameFeedback");
  fb.className = `feedback ${correct ? "good":"bad"}`;
  fb.innerHTML = `<b>${correct ? "Correct!" : "Not quite."}</b> ${safeText(item.why)}`;
  if (!state.gameCompleted) el("nextGameBtn").classList.remove("hidden");
  else toast(`Game completed: ${state.gameScore}/${phishingCases.length*10}`);
  save(); updateDashboard();
}
el("phishBtn").onclick = () => answerGame("phishing");
el("safeBtn").onclick = () => answerGame("safe");
el("nextGameBtn").onclick = () => { state.gameIndex++; save(); renderGame(); };

/* -------------------- QUIZ -------------------- */
let localQuizAnswered = false;
function renderQuiz() {
  const item = quizData[state.quizIndex] || quizData[0];
  el("quizCounter").textContent = `${Math.min(state.quizIndex+1,quizData.length)} / ${quizData.length}`;
  el("quizQuestion").textContent = item.q;
  el("quizOptions").innerHTML = item.o.map((option,i)=>`<button class="quiz-option" data-i="${i}">${String.fromCharCode(65+i)}. ${safeText(option)}</button>`).join("");
  el("quizOptions").querySelectorAll(".quiz-option").forEach(btn => btn.onclick = () => answerQuiz(Number(btn.dataset.i)));
  el("quizFeedback").className = "feedback hidden";
  el("nextQuizBtn").classList.add("hidden");
  localQuizAnswered = false;
  updateDashboard();
}
function answerQuiz(choice) {
  if (localQuizAnswered) return;
  localQuizAnswered = true;
  const item=quizData[state.quizIndex];
  const correct=choice===item.a;
  const options=[...el("quizOptions").children];
  options[item.a].classList.add("correct");
  if(!correct) options[choice].classList.add("wrong");
  const answeredCount=state.quizIndex+1;
  if(correct) state.quizScore=Math.max(state.quizScore,Math.round((answeredCount/quizData.length)*100));
  const fb=el("quizFeedback");
  fb.className=`feedback ${correct?"good":"bad"}`;
  fb.innerHTML=`<b>${correct?"Correct!":"Review this."}</b> ${safeText(item.w)}`;
  if(state.quizIndex<quizData.length-1) el("nextQuizBtn").classList.remove("hidden");
  else { state.quizCompleted=true; toast(`Quiz complete: ${state.quizScore}%`); }
  options.forEach(b=>b.disabled=true);
  save(); updateDashboard();
}
el("nextQuizBtn").onclick=()=>{state.quizIndex++;save();renderQuiz();};

/* -------------------- RISK -------------------- */
function renderRiskQuestions() {
  el("riskQuestions").innerHTML = riskQuestions.map((q,i)=>`
    <div class="risk-question">
      <p>${i+1}. ${q}</p>
      <div class="risk-options">
        <label><input type="radio" name="rq${i}" value="0"> Always</label>
        <label><input type="radio" name="rq${i}" value="1"> Sometimes</label>
        <label><input type="radio" name="rq${i}" value="2"> Rarely</label>
      </div>
    </div>
  `).join("");
}
el("assessBtn").onclick=()=>{
  let total=0;
  for(let i=0;i<riskQuestions.length;i++){
    const radio=document.querySelector(`input[name="rq${i}"]:checked`);
    if(!radio){toast("Please answer every risk question");return;}
    total += Number(radio.value);
  }
  const riskPct=Math.round(total/(riskQuestions.length*2)*100);
  state.riskScore=riskPct; state.riskCompleted=true; save();
  const label=riskPct<=25?"Low":riskPct<=50?"Medium":"High";
  el("riskPercent").textContent=`${riskPct}%`;
  el("riskLabel").textContent=`${label} Risk`;
  el("riskAdvice").textContent=label==="Low"
    ? "Your answers show several strong habits. Keep them consistent."
    : label==="Medium"
    ? "Some habits can be improved. Focus on MFA, unique passwords, updates, backups, and link checking."
    : "Several habits need attention. Start with account protection, cautious links, updates, backups, and keeping secrets private.";
  const deg=riskPct*3.6;
  const color=label==="Low"?"var(--green)":label==="Medium"?"var(--yellow)":"var(--red)";
  el("riskRing").style.background=`conic-gradient(${color} 0deg ${deg}deg, #1b263c ${deg}deg 360deg)`;
  updateDashboard();
  toast("Risk profile updated");
};

/* -------------------- DASHBOARD -------------------- */
function updateDashboard() {
  const scans=state.scans.length;
  const flags=state.scans.filter(s=>s.score>=30).length;
  el("heroScans").textContent=scans;
  el("heroThreats").textContent=flags;
  const learning=overallLearning();
  el("heroScore").textContent=`${learning}%`;
  el("overallScore").textContent=`${learning}%`;
  el("analyticsScans").textContent=scans;
  el("analyticsFlags").textContent=flags;
  const completed=[state.gameCompleted,state.quizCompleted,state.riskCompleted].filter(Boolean).length;
  el("completedModules").textContent=`${completed} / 3`;
  el("analyticsMessage").textContent = learning<35 ? "Start with the scanner and complete a learning module." : learning<70 ? "Good progress. Keep practicing secure digital habits." : "Strong progress. Keep reviewing phishing and account-security habits.";

  const gameProgress=state.gameCompleted?100:Math.round(state.gameIndex/phishingCases.length*100);
  const quizProgress=state.quizCompleted?100:Math.round(state.quizIndex/quizData.length*100);
  const riskProgress=state.riskCompleted?100:0;
  setBar("gameProgress",gameProgress); el("gameProgressText").textContent=`${gameProgress}%`;
  setBar("quizProgress",quizProgress); el("quizProgressText").textContent=`${quizProgress}%`;
  setBar("riskProgress",riskProgress); el("riskProgressText").textContent=`${riskProgress}%`;

  const avg = scans ? Math.round(state.scans.reduce((a,b)=>a+b.score,0)/scans) : 0;
  el("heroStatus").textContent = avg >= 60 ? "ATTENTION" : avg >= 30 ? "CAUTION" : "READY";
  el("heroMeter").style.width = `${Math.max(10,avg)}%`;
  renderBars();
}
function overallLearning() {
  const game=state.gameCompleted?100:Math.round(state.gameIndex/phishingCases.length*100);
  const quiz=state.quizCompleted?state.quizScore:Math.round(state.quizIndex/quizData.length*100);
  const risk=state.riskCompleted ? (state.riskScore<=25?100:state.riskScore<=50?65:35) : 0;
  return Math.round((game+quiz+risk)/3);
}
function setBar(id,v){el(id).style.width=`${clamp(v,0,100)}%`;}
function renderBars(){
  const counts={low:0,medium:0,high:0};
  state.scans.forEach(s=>{if(counts[s.level]!==undefined) counts[s.level]++;});
  const total=Math.max(...Object.values(counts),1);
  el("scanBars").innerHTML=Object.entries(counts).map(([k,v])=>`<div class="bar" style="height:${Math.max(10,v/total*150)}px;background:linear-gradient(180deg,${k==="low"?"var(--green)":k==="medium"?"var(--yellow)":"var(--red)"},transparent)"><span>${v}</span></div>`).join("");
}

applyTheme();
renderHistory();
renderGame();
renderQuiz();
renderRiskQuestions();
updateDashboard();
