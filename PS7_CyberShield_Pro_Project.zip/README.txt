PS-7 CyberShield – Cybersecurity Awareness and Threat Detection Tool

Included features:
1. Modern responsive dashboard UI
2. Live user-input phishing / suspicious-content scanner
3. Rule-based URL and message analysis with risk score and explanations
4. Scan history using browser localStorage
5. Interactive phishing detection game
6. Security awareness quiz
7. Personal digital risk assessment
8. Learning analytics and progress bars
9. Theme switcher (dark/light)
10. Mobile navigation

How to run:
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Open index.html using Live Server, or double-click index.html.

Important:
The scanner is an educational rule-based detector implemented in JavaScript. It is not a commercial antivirus, threat-intelligence API, or guaranteed malicious-URL detector. For a production-grade detector, connect the backend to a trusted threat-intelligence service and validate results server-side.
